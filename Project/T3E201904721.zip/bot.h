//
// Created by andremoreira9 on 20/03/20.
//
#include "game.h"
#include <vector>
#ifndef PROJECT_BOT_H
#define PROJECT_BOT_H



int getBotMove(gameData currGame, vector<int> availableMoves);


#endif //PROJECT_BOT_H
