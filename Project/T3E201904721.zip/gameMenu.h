//
// Created by andremoreira9 on 10/03/20.
//

#ifndef PROJECT_GAMEMENU_H
#define PROJECT_GAMEMENU_H


void play();
void options();
void rules();
bool exit();
void run();


#endif //PROJECT_GAMEMENU_H


